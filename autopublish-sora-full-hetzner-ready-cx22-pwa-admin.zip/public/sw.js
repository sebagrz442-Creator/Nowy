self.addEventListener('install', e => {
  e.waitUntil(caches.open('sora-v1').then(c => c.addAll(['/dashboard/','/dashboard/index.html','/dashboard/manifest.webmanifest'])));
});
self.addEventListener('activate', e => { self.clients.claim(); });
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (url.pathname.startsWith('/videos/')) return; // don't cache big media
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
