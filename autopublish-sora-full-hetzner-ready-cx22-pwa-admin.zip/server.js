import express from "express";
import dotenv from "dotenv";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import path from "path";
import { fileURLToPath } from "url";
import pino from "pino";
import pinoHttp from "pino-http";
import morgan from "morgan";
import { ensureDirs } from "./src/lib/utils.js";
import { loadConfig } from "./src/lib/config.js";
import { runCleanup } from "./src/lib/cleanup.js";
import { pipelineRouter } from "./src/routes/pipeline.js";
import { trendsRouter } from "./src/routes/trends.js";
import { botRouter } from "./src/routes/bot.js";
import { videosRouter } from "./src/routes/videos.js";
import { uploadRouter } from "./src/routes/upload.js";
import { adminRouter } from "./src/routes/admin.js";
import { loadRuntime, scheduleAutoRun } from "./src/lib/runtime.js";
import { runFullPipeline } from "./src/agents/orchestrator.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const log = pino({ level: process.env.NODE_ENV === "production" ? "info" : "debug" });
const app = express();

function getCfgSafe() {
  try { return loadConfig(); }
  catch {
    return {
      OPENAI_MODEL_GPT: process.env.OPENAI_MODEL_GPT || "gpt-4.1-mini",
      OPENAI_MODEL_SORA: process.env.OPENAI_MODEL_SORA || "sora-2",
      BASE_URL: process.env.BASE_URL || "http://localhost:3000",
      PORT: Number(process.env.PORT || 3000),
      CLEAN_ENABLED: true,
      CLEAN_INTERVAL_MINUTES: 720,
      CLEAN_KEEP_DAYS: 7,
      CLEAN_MAX_FILES: 500,
      CLEAN_MAX_SIZE_GB: 5,
      AUTO_RUN: false,
      AUTO_RUN_INTERVAL_MINUTES: 30,
      AUTO_RUN_PLATFORM: "TikTok",
      AUTO_RUN_LANGUAGE: "English"
    };
  }
}
const cfg = getCfgSafe();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: "5mb" }));
app.use(pinoHttp({ logger: log }));
if (process.env.NODE_ENV !== "production") app.use(morgan("dev"));
app.use(rateLimit({ windowMs: 60_000, max: 40, standardHeaders: true, legacyHeaders: false }));

const publicDir = path.join(__dirname, "public");
const videosDir = path.join(__dirname, "videos");
const assetsImagesDir = path.join(__dirname, "assets", "images");
const assetsRoot = path.join(__dirname, "assets");
ensureDirs([publicDir, videosDir, assetsImagesDir]);

app.use("/dashboard", express.static(publicDir));
app.use("/videos", express.static(videosDir));
app.use("/assets/images", express.static(assetsImagesDir)); // previews / uploads
app.use("/assets", express.static(assetsRoot));             // fonts, music

app.get("/healthz", (_req, res) => {
  const c = getCfgSafe();
  res.json({ ok: true, env: process.env.NODE_ENV || "development", models: { gpt: c.OPENAI_MODEL_GPT, sora: c.OPENAI_MODEL_SORA }, time: new Date().toISOString() });
});

app.use("/api/pipeline", pipelineRouter);
app.use("/api/trends", trendsRouter);
app.use("/api/bot", botRouter);
app.use("/api/videos", videosRouter);
app.use("/api/upload", uploadRouter);
app.use("/api/admin", adminRouter);

app.use((req, res) => res.status(404).json({ ok: false, error: "Not found" }));
app.use((err, req, res, _next) => {
  req?.log?.error?.(err) || log.error(err);
  res.status(err.status || 500).json({ ok: false, error: err.message || "Internal Server Error" });
});

// Auto-cleaner
if (cfg.CLEAN_ENABLED) {
  const intervalMs = Math.max(5, cfg.CLEAN_INTERVAL_MINUTES) * 60_000;
  const run = async () => {
    try {
      const stats = await runCleanup({ dir: videosDir, maxAgeDays: cfg.CLEAN_KEEP_DAYS, maxFiles: cfg.CLEAN_MAX_FILES, maxSizeGB: cfg.CLEAN_MAX_SIZE_GB, logger: log });
      log.info({ cleanup: stats }, "videos cleanup done");
    } catch (e) { log.warn({ err: e?.message }, "videos cleanup failed"); }
  };
  setTimeout(run, 30_000);
  setInterval(run, intervalMs);
  log.info(`Auto-cleaner: every ${cfg.CLEAN_INTERVAL_MINUTES} min; keep ${cfg.CLEAN_MAX_FILES} files / ${cfg.CLEAN_KEEP_DAYS} days / ${cfg.CLEAN_MAX_SIZE_GB} GB`);
}

// Optional auto-run
if (cfg.AUTO_RUN && process.env.OPENAI_API_KEY) {
  const every = Math.max(5, cfg.AUTO_RUN_INTERVAL_MINUTES) * 60_000;
  const tick = async () => {
    try {
      const topic = `Auto trend ${new Date().toISOString().slice(0, 16)}`;
      await runFullPipeline({ topic, platform: cfg.AUTO_RUN_PLATFORM, audienceLanguage: cfg.AUTO_RUN_LANGUAGE, durationSec: 20 });
      log.info({ topic }, "Auto pipeline done");
    } catch (e) { log.error(e, "Auto pipeline failed"); }
  };
  setInterval(tick, every);
  log.info(`Auto-run enabled every ${cfg.AUTO_RUN_INTERVAL_MINUTES} min`);
}

loadRuntime();
// re-schedule auto-run with runtime settings (no restart needed)
try { scheduleAutoRun((opts) => runFullPipeline(opts)); } catch {}

const port = Number(cfg.PORT) || 3000;
app.listen(port, () => {
  log.info(`Server listening: http://localhost:${port}`);
  log.info(`Dashboard: ${cfg.BASE_URL.replace(/\/$/, "")}/dashboard/`);
});
