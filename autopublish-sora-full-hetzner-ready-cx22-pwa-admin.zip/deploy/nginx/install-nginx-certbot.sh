#!/usr/bin/env bash
set -euo pipefail
apt-get update -y && apt-get install -y nginx certbot python3-certbot-nginx
ufw allow 'Nginx Full' || true
mkdir -p /var/www/certbot
echo "Symlink deploy/nginx/your.domain.conf into /etc/nginx/sites-enabled and reload nginx"
