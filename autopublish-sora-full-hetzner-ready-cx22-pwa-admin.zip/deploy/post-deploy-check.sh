#!/usr/bin/env bash
set -e
DOMAIN="${1:-your.domain}"
curl -fsSL "https://$DOMAIN/healthz" || exit 1
echo "OK -> https://$DOMAIN/dashboard"
