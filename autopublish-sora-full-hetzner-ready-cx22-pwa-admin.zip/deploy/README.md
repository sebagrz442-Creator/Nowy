# Hetzner (Docker + Caddy)
1) Install Docker & UFW, open 80/443.
2) Copy project to /opt/autopublish, set DNS A your.domain -> server IP.
3) cp .env.example.production .env (set OPENAI_API_KEY).
4) docker compose up -d --build
5) https://your.domain/dashboard


### Auto-updates (Watchtower)
- Włączone jako osobna usługa w `docker-compose.yml` (label-only).
- Aktualizuje tylko kontenery z etykietą `com.centurylinklabs.watchtower.enable=true` (app, caddy).
- Domyślny polling: co 30 min (`WATCHTOWER_POLL_INTERVAL=1800`).
- Sprząta stare obrazy: `WATCHTOWER_CLEANUP=true`.
- Rolling restart: `WATCHTOWER_ROLLING_RESTART=true`.
- (Opcjonalnie) powiadomienia: ustaw `WATCHTOWER_NOTIFICATION_URL` w `.env` (Shoutrrr).



### Production overrides (limits + log rotate)
Use resource limits & log rotation by composing an override file:
```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
```
Tune values to your Hetzner plan:
- CX22 (2 vCPU / 4 GB): app cpus 1.5, mem 1.5–2G; caddy 0.5/256M; watchtower 0.25/128M.
- CX32 (4 vCPU / 8 GB): app cpus 2.5–3, mem 3–4G; caddy 0.5/256M; watchtower 0.25/128M.

> Note: `deploy.resources.*` is honored in Swarm; with plain compose some limits may be ignored depending on engine. Logging rotation works everywhere via `json-file` options.



### CX22 (2 vCPU / 4 GB) profile
Use dedicated override for safe headroom:
```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml -f docker-compose.cx22.yml up -d --build
```
Notes:
- `FFMPEG_THREADS=2` keeps CPU in check.
- App memory limit 3G leaves ~1G for OS + Caddy/Watchtower.
- You can raise to 3.2–3.5G if videos are complex, but watch for OOM.



### Control from phone (PWA)
- Dashboard jest **instalowalny**: dodaj do ekranu głównego (manifest + service worker).
- Link: `https://your.domain/dashboard`.

### Admin token
- Ustaw `ADMIN_TOKEN` w `.env`. W dashboardzie, w sekcji **Admin**, wklej token → odblokujesz: auto-run config, update-now, check-updates.
- Zabezpiecza endpointy: `/api/admin/*`.

### GitHub-based updates (GHCR + Watchtower)
1) Zrób push na `main` → **GitHub Actions** zbuduje i opublikuje obraz do **GHCR** (`ghcr.io/<owner>/<repo>:latest`).
2) Na serwerze użyj override obrazu:
```bash
docker compose -f docker-compose.yml -f deploy/compose.image.yml up -d
```
3) **Watchtower** sam pobierze nowy obraz (co 30 min) lub kliknij **Update now** w dashboardzie (wywołuje HTTP API Watchtower).

### Watchtower HTTP API
- Ustaw `WATCHTOWER_HTTP_API_TOKEN` w `.env`. Dashboard użyje go do `/api/admin/update-now`.
