$ok = $true
Write-Host "PWD: $((Get-Location).Path)"
if (Test-Path .\server.js) { Write-Host "[OK] server.js" } else { Write-Host "[X] Missing server.js" -ForegroundColor Red; $ok=$false }
if (Test-Path .\package.json) { Write-Host "[OK] package.json" } else { Write-Host "[X] Missing package.json" -ForegroundColor Red; $ok=$false }
try { node -v | Out-Null; Write-Host "[OK] Node" } catch { Write-Host "[X] Node not found in PATH" -ForegroundColor Red; $ok=$false }
try { npm -v  | Out-Null; Write-Host "[OK] npm"  } catch { Write-Host "[X] npm not found in PATH"  -ForegroundColor Red; $ok=$false }
try { ffmpeg -version | Out-Null; Write-Host "[OK] ffmpeg" } catch { Write-Host "[i] ffmpeg not found (recommended for merge)" -ForegroundColor Yellow }
if (Test-Path .\.env) {
  $envOk = Select-String -Path .\.env -Pattern '^OPENAI_API_KEY=.+' -Quiet
  if ($envOk) { Write-Host "[OK] .env has OPENAI_API_KEY" } else { Write-Host "[X] .env missing OPENAI_API_KEY" -ForegroundColor Red; $ok=$false }
} else { Write-Host "[X] .env missing (copy .env.example -> .env)" -ForegroundColor Yellow }
if (-not (Test-Path .\node_modules)) { Write-Host "[i] Run npm install" -ForegroundColor Yellow } else { Write-Host "[OK] node_modules present" }
if (-not $ok) { exit 1 } else { exit 0 }
