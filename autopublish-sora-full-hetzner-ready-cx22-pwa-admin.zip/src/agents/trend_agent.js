import { callChat } from "./openai_client.js";
import { loadConfig } from "../lib/config.js";

export async function generateTrendIdeas({ topic, platform, audienceLanguage }) {
  const cfg = loadConfig();
  if (cfg.TRENDS_API_URL) {
    try {
      const url = `${cfg.TRENDS_API_URL}?platform=${encodeURIComponent(platform || "")}&lang=${encodeURIComponent(audienceLanguage || "")}&q=${encodeURIComponent(topic || "")}`;
      const r = await fetch(url);
      if (r.ok) {
        const data = await r.json();
        if (Array.isArray(data?.ideas) && data.ideas.length) return data.ideas.slice(0, 10);
      }
    } catch {}
  }
  const sys = `You generate viral short-video ideas for ${platform}. Respond in ${audienceLanguage}. Return a numbered list of concise idea titles only.`;
  const user = topic && topic.trim().length > 2 ? `Given topic: "${topic}". Generate 10 very short ideas.` : `No topic given. Generate 10 hot ideas for today.`;
  const text = await callChat(sys, user);
  return text.split(/\n+/).map(s => s.replace(/^\d+[\).]\s*/, "").trim()).filter(Boolean).slice(0, 10);
}
