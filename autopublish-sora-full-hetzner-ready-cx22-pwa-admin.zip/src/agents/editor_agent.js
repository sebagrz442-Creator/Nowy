import { callChat } from "./openai_client.js";
export async function editScript({ script, audienceLanguage }) {
  const sys = `You are a ruthless editor. Language: ${audienceLanguage}. Keep length 80-120 words. Make it clearer, more emotional, and easy to speak.`;
  const user = `Polish this script for narration. Return only edited text:\n\n${script}`;
  return callChat(sys, user);
}
