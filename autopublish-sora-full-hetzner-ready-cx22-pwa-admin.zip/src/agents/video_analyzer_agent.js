import { callChat } from "./openai_client.js";
export async function analyzeVideo({ idea, plan, audienceLanguage }) {
  const sys = `You are a short video QA. Language: ${audienceLanguage}.`;
  const user = `Idea: ${idea}\nTone: ${plan.tone}\nProvide 3 bullet suggestions to improve visuals pacing and overlay text.`;
  return callChat(sys, user);
}
