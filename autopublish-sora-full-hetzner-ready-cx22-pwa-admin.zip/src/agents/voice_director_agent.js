import { callChat } from "./openai_client.js";
export async function planVoiceAndVideo({ editedScript, audienceLanguage }) {
  const sys = `Voice director. Decide tone (e.g., calm, energetic, inspirational, funny), pace (slow/medium/fast), and pick voice gender-neutral suggestion. Language: ${audienceLanguage}.`;
  const user = `Script:\n${editedScript}\nReturn JSON with {tone, pace, voiceHint}.`;
  const text = await callChat(sys, user);
  let plan = { tone: "energetic", pace: "medium", voiceHint: "alloy" };
  try { plan = { ...plan, ...JSON.parse(text) }; } catch {}
  const voice = /calm|deep/i.test(plan.tone) ? "ember" :
                /funny|playful/i.test(plan.tone) ? "verse" :
                /inspir/i.test(plan.tone) ? "alloy" : "alloy";
  return { ...plan, voice };
}
