import { callChat } from "./openai_client.js";
export async function generateDescription({ platform, language, idea, editedScript }) {
  const lang = String(platform||"").toLowerCase()==="tiktok" ? "English" : (language||"English");
  const sys = `You write a one or two-line social video description. Keep it concise, vivid, and friendly. Language: ${lang}.`;
  const user = `Idea: ${idea}
Script:
${editedScript}

Constraints:
- 1-2 sentences, punchy.
- No hashtags in the description (they will be added separately).
Return plain text only.`;
  const text = await callChat(sys, user);
  return (text||"").trim();
}
