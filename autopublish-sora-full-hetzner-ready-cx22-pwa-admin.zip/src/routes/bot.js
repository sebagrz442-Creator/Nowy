import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../lib/utils.js";
import { callChat } from "../agents/openai_client.js";

const router = Router();

const IdeasSchema = z.object({
  prompt: z.string().min(3),
  platform: z.string().default("TikTok"),
  language: z.string().default("English"),
  n: z.coerce.number().int().min(1).max(20).default(10)
});

router.post("/ideas", asyncHandler(async (req, res) => {
  const parsed = IdeasSchema.safeParse(req.body || {});
  if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error.flatten() });
  const base = parsed.data;
  const language = base.platform.toLowerCase() === "tiktok" ? "English" : base.language;

  const sys = `You are a trends bot for ${base.platform}. Respond in ${language}. Return a list of ${base.n} short idea titles only.`;
  const txt = await callChat(sys, base.prompt);
  const ideas = txt.split(/\n+/).map(s => s.replace(/^\d+[\).]\s*/, "").trim()).filter(Boolean).slice(0, base.n);
  res.json({ ok: true, platform: base.platform, language, ideas });
}));

export const botRouter = router;
