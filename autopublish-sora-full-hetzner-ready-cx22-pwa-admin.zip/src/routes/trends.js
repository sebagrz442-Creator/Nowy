import { Router } from "express";
import { generateTrendIdeas } from "../agents/trend_agent.js";
import { asyncHandler } from "../lib/utils.js";

const router = Router();

router.get("/", asyncHandler(async (req, res) => {
  const q = String(req.query.q ?? "");
  const platform = String(req.query.platform ?? "TikTok");
  const lang = platform.toLowerCase() === "tiktok" ? "English" : String(req.query.lang ?? "English");
  const ideas = await generateTrendIdeas({ topic: q, platform, audienceLanguage: lang });
  res.json({ ok: true, platform, language: lang, ideas });
}));

export const trendsRouter = router;
