import { Router } from "express";
import os from "os";
import { getRuntime, setRuntime } from "../lib/runtime.js";

const router = Router();

function requireAdmin(req, res, next) {
  const token = process.env.ADMIN_TOKEN || "";
  if (!token) return next(); // no token set -> open (for private servers only)
  const provided = req.headers["x-admin-token"] || req.query.token;
  if (String(provided) === token) return next();
  return res.status(401).json({ ok: false, error: "Unauthorized" });
}

router.get("/status", requireAdmin, async (req, res) => {
  const uptime = process.uptime();
  const mem = process.memoryUsage();
  res.json({
    ok: true,
    version: process.env.APP_VERSION || "dev",
    node: process.version,
    platform: process.platform,
    arch: process.arch,
    hostname: os.hostname(),
    uptime,
    mem,
    runtime: getRuntime(),
    watchtower: {
      url: process.env.WATCHTOWER_HTTP_URL || "http://watchtower:8080",
      enabled: true
    }
  });
});

router.post("/update-now", requireAdmin, async (req, res) => {
  const base = process.env.WATCHTOWER_HTTP_URL || "http://watchtower:8080";
  const token = process.env.WATCHTOWER_HTTP_API_TOKEN || process.env.WATCHTOWER_HTTP_TOKEN || "";
  try {
    const r = await fetch(`${base.replace(/\/$/,"")}/v1/update?token=${encodeURIComponent(token)}`, { method: "POST" });
    const txt = await r.text();
    return res.json({ ok: r.ok, status: r.status, body: txt });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

router.get("/check-updates", requireAdmin, async (req, res) => {
  const owner = process.env.GH_OWNER || "";
  const repo = process.env.GH_REPO || "";
  if (!owner || !repo) return res.status(400).json({ ok: false, error: "GH_OWNER/GH_REPO not set" });
  const token = process.env.GITHUB_TOKEN || "";
  try {
    const r = await fetch(`https://api.github.com/repos/${owner}/${repo}/releases/latest`, {
      headers: token ? { Authorization: `Bearer ${token}`, "User-Agent": "autopublish/1.0" } : { "User-Agent": "autopublish/1.0" }
    });
    const j = await r.json();
    res.json({ ok: true, release: j });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

router.get("/config", requireAdmin, (req, res) => {
  res.json({ ok: true, config: getRuntime() });
});

router.put("/config", requireAdmin, (req, res) => {
  const b = req.body || {};
  const patch = {};
  if ("autoRunEnabled" in b) patch.autoRunEnabled = !!b.autoRunEnabled;
  if ("autoRunIntervalMinutes" in b) patch.autoRunIntervalMinutes = Math.max(5, parseInt(b.autoRunIntervalMinutes));
  if ("autoRunPlatform" in b) patch.autoRunPlatform = String(b.autoRunPlatform || "TikTok");
  if ("autoRunLanguage" in b) patch.autoRunLanguage = String(b.autoRunLanguage || "English");
  const out = setRuntime(patch);
  res.json({ ok: true, config: out });
});

export const adminRouter = router;
