import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { exec as execCb } from "node:child_process";
import { promisify } from "node:util";
import { loadConfig } from "../lib/config.js";
const exec = promisify(execCb);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");

function clamp(x, lo, hi) { return Math.min(hi, Math.max(lo, x)); }
function sanitizeText(s) {
  return String(s || "").replace(/[\r\n]+/g, " ").replace(/[\\\"`]/g, "").replace(/'/g, "’").trim();
}
function firstSentence(text, fallback) {
  const t = String(text || "").trim();
  if (!t) return fallback || "";
  const m = t.match(/^(.{0,80}?)([\.!\?]|$)/);
  return (m && m[1]) ? m[1] : (t.slice(0, 80));
}

const TRANSITIONS_SOFT = ["fade","smoothleft","smoothright","wipeleft","wiperight","wipeup","wipedown"];
const TRANSITIONS_HARD = ["slideleft","slideright","slideup","slidedown","circleopen","circleclose","radial","pixelize","hblur","vblur"];
const TRANSITIONS_AUTO = [...TRANSITIONS_SOFT, ...TRANSITIONS_HARD];

/**
 * Dynamic slideshow (Ken Burns + random transitions) with overlays.
 */
export async function generateVideoFallback({
  idea,
  editedScript,
  plan,
  durationSec,
  images = [],
  overlayCtaText = "Follow for more",
  zoomMode = "mix",           // in|out|mix
  transitionsMode = "auto",   // auto|soft|hard
  progressBar = true,
  safeArea = "tiktok",        // "tiktok" | "tiktok_strict" | "none"
  progressThickness = 8,
  overlayFontName = "Arial",
  overlayHookSize = 48,
  overlayCtaSize = 44
}) {
  const cfg = loadConfig();
  const fps = 30;
  const xfadeDur = 0.8;
  const width = 1080, height = 1920;
  const totalSec = clamp(Number(durationSec || cfg.VIDEO_DEFAULT_SEC), cfg.VIDEO_MIN_SEC, cfg.VIDEO_MAX_SEC);
  const overlayFontFile = cfg.OVERLAY_FONT_FILE || "";

  // Images or placeholders
  let items = Array.isArray(images) ? images : [];
  if (!items.length) {
    const tmpDir = path.join(projectRoot, "videos", `tmp_colors_${Date.now()}`);
    fs.mkdirSync(tmpDir, { recursive: true });
    const colors = ["#0ea5e9", "#8b5cf6", "#10b981"];
    items = [];
    for (let i = 0; i < colors.length; i++) {
      const outPng = path.join(tmpDir, `color_${i + 1}.png`);
      await exec(`ffmpeg -y -f lavfi -i color=c=${colors[i].replace("#","")}:s=${width}x${height}:d=0.1 -frames:v 1 "${outPng}"`);
      items.push({ path: outPng, mime: "image/png" });
    }
  }

  // Per-image durations
  const n = items.length;
  const minPerImage = 2;
  const base = Math.max(minPerImage, Math.floor(totalSec / n));
  const cum = []; const perDur = [];
  let sum = 0;
  for (let i = 0; i < n; i++) {
    let d = base;
    if (sum + d < totalSec) {
      const room = totalSec - (sum + d);
      if (room > 0 && i < Math.min(n, Math.floor(room))) d += 1;
    }
    perDur.push(d); sum += d; cum.push(sum);
  }

  const ts = Date.now();
  const out = path.join(projectRoot, "videos", `raw_${ts}.mp4`);

  // Inputs
  const inputs = [];
  for (let i = 0; i < n; i++) inputs.push(`-loop 1 -t ${perDur[i]} -i "${items[i].path || items[i]}"`);

  // Filters: scale+pad → zoompan (Ken Burns)
  const filters = [];
  for (let i = 0; i < n; i++) {
    const frames = perDur[i] * fps;
    const chooseIn = zoomMode === "in" ? true : zoomMode === "out" ? false : Math.random() < 0.5;
    const zStart = chooseIn ? 1.0 : 1.10;
    const zEnd   = chooseIn ? 1.10 : 1.0;
    const step   = Math.abs(zEnd - zStart) / Math.max(1, frames - 1);
    const zExpr  = chooseIn
      ? `min(${zStart}+on*${step.toFixed(6)},${zEnd})`
      : `max(${zStart}-on*${step.toFixed(6)},${zEnd})`;

    filters.push(
      `[${i}:v]scale=${width}:-2,setsar=1:1,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,` +
      `zoompan=z='${zExpr}':x='(iw-iw/zoom)/2':y='(ih-ih/zoom)/2':d=${frames}:s=${width}x${height},` +
      `fps=${fps},format=yuv420p,setpts=PTS-STARTPTS[s${i}]`
    );
  }

  // Transitions
  const pool = transitionsMode === "soft" ? TRANSITIONS_SOFT
             : transitionsMode === "hard" ? TRANSITIONS_HARD
             : TRANSITIONS_AUTO;

  let prevLabel = `s0`;
  for (let i = 1; i < n; i++) {
    const offset = Math.max(0, (cum[i - 1] - xfadeDur * i));
    const nextLabel = `x${i}`;
    const tr = pool[Math.floor(Math.random() * pool.length)];
    filters.push(`[${prevLabel}][s${i}]xfade=transition=${tr}:duration=${xfadeDur}:offset=${offset}[${nextLabel}]`);
    prevLabel = nextLabel;
  }

  // Overlays: safe area + sizes
  const hook = sanitizeText(firstSentence(editedScript, idea));
  const cta  = sanitizeText(overlayCtaText || "Follow for more ✨");
  const finalDur = Math.max(0, sum - xfadeDur*(n-1));
  const pad = (safeArea === "tiktok") ? { top: 220, bottom: 420, left: 80, right: 80 }
            : (safeArea === "tiktok_strict" ? { top: 300, bottom: 560, left: 100, right: 100 } : { top: 80, bottom: 120, left: 40, right: 40 });
  const barH = Math.max(2, Math.min(24, Number(progressThickness)||8));
  const finalLabel = "vout";
  const progress = progressBar
    ? `,drawbox=x=0:y=(pad.top - (10 + ${barH})):w=(w*t/${finalDur.toFixed(2)}):h=${barH}:color=white@0.6:t=fill:enable='between(t,0,${finalDur.toFixed(2)})'`
    : "";

  const fontPart = overlayFontFile ? `fontfile='${overlayFontFile}':` : "";
  filters.push(
    `[${prevLabel}]` +
    `drawtext=${fontPart}text='${hook}':x=(w-text_w)/2:y=(${pad.top}):fontsize=${overlayHookSize}:fontcolor=white:box=1:boxcolor=black@0.5:boxborderw=12:enable='between(t,0,3)',` +
    `drawtext=${fontPart}text='${cta}':x=(w-text_w)/2:y=(h - ${pad.bottom} - text_h - 10):fontsize=${overlayCtaSize}:fontcolor=white:box=1:boxcolor=black@0.5:boxborderw=10:enable='between(t,${Math.max(0, finalDur-3).toFixed(2)},${finalDur.toFixed(2)})'` +
    `${progress}` +
    `[${finalLabel}]`
  );

  const threads = process.env.FFMPEG_THREADS ? `-threads ${Number(process.env.FFMPEG_THREADS)}` : ""; 
  const preset = process.env.FFMPEG_PRESET ? `-preset ${process.env.FFMPEG_PRESET}` : ""; 
  const cmd = [
    "ffmpeg -y", " " + threads, " " + preset,
    inputs.join(" "),
    `-filter_complex "${filters.join(";")}"`,
    `-map "[${finalLabel}]"`,
    "-c:v libx264 -pix_fmt yuv420p -r 30 -movflags +faststart",
    `"${out}"`
  ].join(" ");

  await exec(cmd);

  const size = fs.statSync(out).size;
  return {
    filePath: out,
    videoUrl: `/videos/${path.basename(out)}`,
    job: { id: `fallback-${ts}`, status: "completed", seconds: totalSec, size, engine: "ffmpeg-slideshow-dynamic" }
  };
}
