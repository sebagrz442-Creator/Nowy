import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { openaiClient } from "../agents/openai_client.js";
import { loadConfig } from "../lib/config.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");

export async function generateVideoWithSora({ idea, editedScript, plan, durationSec, images = [] }) {
  const cfg = loadConfig();
  const model = cfg.OPENAI_MODEL_SORA;
  const clamped = Math.min(cfg.VIDEO_MAX_SEC, Math.max(cfg.VIDEO_MIN_SEC, durationSec || cfg.VIDEO_DEFAULT_SEC));

  const content = [];
  content.push({ type: "text", text: `Create a ${clamped} seconds vertical short video for "${idea}". Tone: ${plan.tone}. Visual pacing: ${plan.pace}. Use lively, modern style.` });
  content.push({ type: "text", text: `Ensure vertical aspect ratio 9:16, safe for overlay text.` });
  for (const img of images) content.push({ type: "input_image", image_data: img.b64, mime_type: img.mime });
  content.push({ type: "text", text: `Key narration text to align visuals:\n${editedScript}` });

  const response = await openaiClient.responses.create({
    model,
    input: [{ role: "user", content }]
  });

  const out = response?.output?.find?.(o => o?.content?.[0]?.type === "output_file");
  const fileId = out?.content?.[0]?.file_id;
  const ts = Date.now();
  let filePath = path.join(projectRoot, "videos", `raw_${ts}.mp4`);

  if (fileId) {
    const fileStream = await openaiClient.files.content(fileId);
    const bufs = []; for await (const chunk of fileStream.body) bufs.push(chunk);
    fs.writeFileSync(filePath, Buffer.concat(bufs));
  } else {
    const maybe = response?.output?.[0]?.content?.find?.(c => c.type === "video");
    if (!maybe?.data) throw new Error("Sora did not return a video file.");
    fs.writeFileSync(filePath, Buffer.from(maybe.data, "base64"));
  }
  const size = fs.statSync(filePath).size;
  return { filePath, videoUrl: `/videos/${path.basename(filePath)}`, job: { id: response?.id, status: "completed", seconds: clamped, size } };
}
