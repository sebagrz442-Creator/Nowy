Place background music as 'bg.mp3' here.
